import nltk
from collections import Counter
from nltk.tokenize import PunktTokenizer
import string
from wordcloud import WordCloud
import matplotlib.pyplot as plt

nltk.download("punkt")


with open("text.txt", "r", encoding="utf-8") as f:
    text = f.read()

# Basic cleanup
text = text.replace("\n", " ")
words = nltk.word_tokenize(text.lower())
words = [w for w in words if w.isalpha()]

# Word count
total_words = len(words)

# Sentence count
sentences = nltk.sent_tokenize(text)
avg_sentence_length = total_words / len(sentences)

# Most common words
word_freq = Counter(words).most_common(10)


wc = WordCloud(width=800, height=400, background_color="white").generate(
    " ".join(words)
)
plt.imshow(wc, interpolation="bilinear")
plt.axis("off")
plt.show()
